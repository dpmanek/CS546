const albums = require('./albums');
const bands = require('./bands');

module.exports = {
	albums: albums,
	bands: bands,
};
